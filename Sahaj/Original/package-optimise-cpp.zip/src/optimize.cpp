#include "optimize.h"
#include <vector>
using namespace std;

vector<vector<int>> optimise(int containerSize , vector<int> groupSizes) {
    vector<vector<int>> optimal_groups;
    return optimal_groups;
}
