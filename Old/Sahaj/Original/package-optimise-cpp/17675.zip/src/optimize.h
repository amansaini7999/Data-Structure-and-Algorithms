#include <iostream>
#include <vector>

using namespace std;

vector<vector<int>> optimise(int containerSize, vector<int> groupSizes);
